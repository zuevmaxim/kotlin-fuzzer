#! /bin/bash

while true
do
    bash /home/m/script.sh
    sleep 1
done

