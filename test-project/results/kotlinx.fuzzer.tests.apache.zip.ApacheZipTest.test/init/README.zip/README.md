# SDPracticeDocker 1
Start: `./start.sh`

script.sh is called with 1 second period

