#!/bin/bash

sudo apt-get install git g++ gummi texlive-full make vlc cmake # telegram-desktop

firefox yandex.ru google.com vk.com mail.ru gitlab.com github.com wiki.compscicenter.ru http://detexify.kirelabs.org/classify.html https://translate.google.com/ http://hwproj.me/courses/51

firefox https://www.jetbrains.com/toolbox-app/download


